export const countries = [
    {
        image: "./images/brazil.webp",
        title: "超越感測界線，極致健康生活",
        url: 'https://www.ultraehp.com'
    },
    {
        image: "./images/brazil.webp",
        title: "China",
    },
    {
        image: "./images/brazil.webp",
        title: "France",
    },
    {
        image: "./images/brazil.webp",
        title: "Japan",
    },
    {
        image: "./images/brazil.webp",
        title: "Norway",
    },
];
