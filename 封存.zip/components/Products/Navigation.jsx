import React from "react";
import { Tabs, Tab } from "@nextui-org/react";

import Link from "next/link"


export default function App() {
    const radiusList = [
        "full",

    ];

    return (
        <div className="flex flex-wrap gap-4">
            <div className="wrap  bg-amber-100 rounded-full	opacity-60 px-7 py-1 flex">
                <Link href='../Products'>

                    <p className="text-black">Back to products</p>

                </Link>
                <span className="mx-5 color-black">/</span>
                <Link href='../Products'>

                    <p className="text-black">Back to products</p>

                </Link>
            </div>
        </div>
    );
}
