import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/thumbs";
export { Navigation, Thumbs, Pagination } from "swiper";
export { Swiper, SwiperSlide } from "swiper/react";