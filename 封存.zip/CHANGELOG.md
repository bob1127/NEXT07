# CHANGELOG.md

## [2.3.0] - 2023-06-20

Fix issue with Google Fonts

## [2.2.1] - 2023-06-13

Fix minor issue

## [2.2.0] - 2023-05-31

Update dependencies and fix some issues

## [2.1.0] - 2023-05-07

Modal video improvements

## [2.0.0] - 2023-03-31

Conversion to Next.js

## [1.3.3] - 2023-03-28

- Fix video

## [1.3.2] - 2023-03-28

- Add self-hosted video

## [1.3.1] - 2023-02-13

- Update dependencies

## [1.3.0] - 2022-07-15

- Update dependencies
- Update React to v18
- Replace Sass with CSS files

## [1.1.0] - 2022-01-27

- Replace CRA (Create React App) with Vite
- Remove Craco
- Update dependencies

## [1.0.1] - 2020-10-19

Fix issue with testimonail image on mobile

## [1.0.0] - 2020-10-15

First release
